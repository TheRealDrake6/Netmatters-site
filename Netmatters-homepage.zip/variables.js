const $burger = $(".hamburger");
const $hamburgerContainer = $(".nav-container-burger");
const $bodyAll = $(".main-body");
const $sideBar = $(".sidebar");
const $headerAll = $(".sticky-container");
let lastScrollTop = 0;
let scrollThreshold = 50;