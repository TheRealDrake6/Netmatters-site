<?php
$host = "localhost";
$dbname = "netmatters-database";
$username = "root";
$password = "";